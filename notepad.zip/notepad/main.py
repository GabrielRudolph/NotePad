
import os
from tkinter import *
from tkinter import filedialog, colorchooser, font
from tkinter.messagebox import *
from tkinter.filedialog import *

def font_color():
    color = colorchooser.askcolor(title="Choose a Color")
    text_area.config(fg=color[1])

def font_type(*args):
    text_area.config(font=(font_name.get(), size_btn.get()))

def new_file():
    window.title("Unbennant")
    text_area.delete(1.0, END)

def open_file():
    file = askopenfilename(defaultextension=".txt",
                           file=[("Alle Dateien", "*.*"),
                           ("Text Dokumente", "*.txt")])

    try:
        window.title(os.path.basename(file))
        text_area.delete(1.0, END)

        file = open(file, "r")

        text_area.insert(1.0, file.read())

    except Exception:
        print("couldnt read file = Line 19")

def save_file():
    file = filedialog.asksaveasfilename(initialfile='Unbennant.txt',
                                    defaultextension=".txt",
                                    filetypes=[("Alle Dateien", "*.*"),
                                               ("Text Dokumente", "*.txt")])

    if file is None:
        return

    else:
        try:
            window.title(os.path.basename(file))
            file = open(file, "w")

            file.write(text_area.get(1.0, END))


        except Exception:
            print("Couldnt save file = Line 35")

        finally:
            file.close()

def cut_txt():
    text_area.event_generate("<<Cut>>")

def copy_txt():
    text_area.event_generate("<<Copy>>")

def paste_txt():
    text_area.event_generate("<<Paste>>")

def about():
    showinfo("About this Program", "This Notepad is written by Gabriel Rudolph")

def quit_prg():
    window.destroy()

window = Tk()
window.title("Text Editor - Gabriel R")
file = None

window_width = 500
window_height = 500
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()

x = int((screen_width / 2) - (window_width / 2))
y = int((screen_height / 2) - (screen_height / 2))

window.geometry("{}x{}+{}+{}".format(window_width, window_height, x, y))

font_name = StringVar(window)
font_name.set("Arial")

font_size = StringVar(window)
font_size.set("25")

text_area = Text(window, font=(font_name.get(), font_size.get()))

scroll_bar = Scrollbar(text_area)
window.grid_rowconfigure(0, weight=1)
window.grid_columnconfigure(0, weight=1)
text_area.grid(sticky=N + E + S + W)
scroll_bar.pack(side=RIGHT, fill=Y)
text_area.config(yscrollcommand=scroll_bar.set)


frame = Frame(window)
frame.grid()

color_btn = Button(frame, text="Farbe", command=font_color)
color_btn.grid(row=0, column=0)

# noinspection PyTypeChecker
font_btn = OptionMenu(frame, font_name, *font.families(), command=font_type)
font_btn.grid(row=0, column=1)

size_btn = Spinbox(frame, from_=1, to=100, textvariable=font_size, command=font_type)
size_btn.grid(row=0, column=3)

menu_bar = Menu(window)
window.config(menu=menu_bar)

file_menu = Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="Datei", menu=file_menu)
file_menu.add_command(label="Neu", command=new_file)
file_menu.add_command(label="Öffnen", command=open_file)
file_menu.add_command(label="Speichern", command=save_file)
file_menu.add_separator()
file_menu.add_command(label="Schließen", command=quit_prg)

edit_menu = Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="Bearbeiten", menu=edit_menu)
edit_menu.add_command(label="Ausschneiden", command=cut_txt)
edit_menu.add_command(label="Kopieren", command=copy_txt)
edit_menu.add_command(label="Einfügen", command=paste_txt)

help_menu = Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="Hilfe", menu=help_menu)
help_menu.add_command(label="About", command=about)


window.mainloop()